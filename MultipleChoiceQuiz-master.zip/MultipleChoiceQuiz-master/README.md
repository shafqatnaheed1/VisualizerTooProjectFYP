This Multiple choice quiz is a starter project which will help you with building a quiz. If you run the quiz now as it is when you get to the last question the app will crash.

I leave it up to you to probably design a background; maybe add an image to display pictures; add a screen that will tell you how many questions you got correct. There is so much that you can do with this app starter. You can find the tutorial here on youtube:

https://www.youtube.com/watch?v=4g1_UH_6VQc&feature=youtu.be
